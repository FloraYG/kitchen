HDFS dockers
1、启动镜像，配置映射端口
docker run --name slave1 --hostname slave1 -v /home/user/hadoop_disk/:/usr/local/hadoop/tmp -d -P 2221:22 yg/ubuntu-ssh-root-hadoop-slave
2、获取所有node ip 并配置于 : vi /etc/hosts
3、将datanode信息配置到/usr/local/hadoop/sbin/workers
3、exec 进入bash
format namenode : bin/hdfs namenode -format
4、启动      
/usr/local/hadoop/sbin/start-all.sh

可修改hdfs-site.xml备份数量和block size
 <property>  
       <name>dfs.block.size</name>  
       <value>5242880</value>  <!--1024的整数倍-->   默认64M
 </property>  

